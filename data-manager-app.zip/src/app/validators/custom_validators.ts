/*import { DataService } from './../data.service';


export class IdShouldBeUnique
{
    checkID(id)
    {
        for(let user of this.dataService.sharedData)
        {
            if(user.id===id)
            {
                return true;
            }
        }
        return false;
        
    }
    constructor(private dataService:DataService)
    {

    }
}*/